<!DOCTYPE html>
<?php
@ini_set('zlib.output_compression', 0);
@ini_set('implicit_flush', 1);
@ob_end_clean();
set_time_limit(0);
?>
<html>
    <head>
        <style type="text/css">
            div#content {
                display: none;
            }
            img#loading {
                top: 200 px;
                margin: auto;
                position: absolute;
                z-index: 1000;
                width: 500px;
                height: 24px;
                cursor: wait;
                height: 500px
            }
        </style>
        <style type="text/css"></style>
    </head>
    <body>
        <?php
        for ($i = 0; $i < 10; $i++) {
            echo str_repeat(' ', 1024 * 64); // this is for the buffer achieve the minimum size in order to flush data
            if ($i == 1)
                echo '<img id="loading" src="giphy.gif" />';
        }
        ?>
        <div id="content" style="display: block;">
            <?php
            sleep(5);
           // echo 'This content has been loaded via an AJAX request';
            ?>
            <br>
        </div>
        <script type="text/javascript">
            function preloader() {
                document.getElementById("loading").style.display = "none";
                document.getElementById("content").style.display = "block";
            }//preloader
            window.onload = preloader;
        </script>
    </body>
</html>