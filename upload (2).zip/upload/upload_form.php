
<?php
   if(isset($_FILES['fileToUpload'])){
      $errors= array();
      $file_name = $_FILES['fileToUpload']['name'];
      $file_size =$_FILES['fileToUpload']['size'];
      $file_tmp =$_FILES['fileToUpload']['tmp_name'];
      $file_type=$_FILES['fileToUpload']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['fileToUpload']['name'])));
      
      
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"FILES/".$file_name);
        // echo "Success";
      }else{
         print_r($errors);
      }
   }


?>


<?php
if(isset($_REQUEST['Download']) ){
//$filename = "./folder/";
//if (file_exists($filename)){
$filename='folder/feed.txt';
header("Content-Length: " . filesize($filename));
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename=feed.csv');//.basename($filename)) 

readfile($filename);
//}
}
?>






<?php
if(isset($_REQUEST['Process'])){




$fp=fopen('temp.csv','a');
$row = 0;
$column=1;
if (($handle = fopen("feed.txt", "r")) !== FALSE) {
  while (($data = fgetcsv($handle, 2000, "\t")) !== FALSE) {
  
  // getting number of rows
    $num = count($data);

	$row++;
	if ($row == 1) { continue; }
 //  echo "<p> $num fields in line $row: <br /></p>\n";
   $ins= array();
//   for ($c=1; $c < $num; $c++) { 
       $ins[0]=" ";//data to be transfer
	$ins[1]=$data[0];
	$ins[2]=$data[6];
	$ins[3]=$data[15];
	$ins[4]=$data[12];
	$ins[5]="";
	$ins[6]="";
	$ins[7]="";
	$ins[8]=$data[13];
	$ins[9]="";
	$ins[10]=$data[16];
	$ins[11]=$data[11];
	$ins[12]="";
	$ins[13]=$data[4];
	$ins[14]="";
	$ins[15]=$data[14];
	$ins[16]="";
	$ins[17]="";
	$ins[18]="";
	$ins[19]="";
	$ins[20]="";
	$ins[21]="";
	$ins[22]="";
	$ins[23]="";
	$ins[24]="";
	$ins[25]="";
	$ins[26]="";
	$ins[27]="";
	$ins[28]="";
	$ins[29]=$data[1];
	$ins[29]=$data[2];
	$ins[30]="";
	$ins[31]="";
	$ins[32]="";
	$ins[33]="";
	$ins[34]="";
	$ins[35]="";
	$ins[36]="";
	$ins[37]="";
	$ins[38]="";
	$ins[39]="";
	$ins[40]="";
	$ins[41]=$data[3];
	$ins[42]=$data[5];
	$ins[43]=$data[7];
	$ins[44]=$data[8];
	$ins[45]=$data[9];
$ins[46]=$data[10];
$ins[47]=$data[17];
$ins[48]=$data[18];
$ins[49]="";
 //echo $ins;
  

  // echo $data[$ins] . "<br />\n";	  
  //               }
	fputcsv($fp,$ins);//write data on the file

  }
 fclose($handle);
}

}


?>




<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Upload Content Form</title>

	
	<link rel="stylesheet" href="assets/form-mini.css">
<script type="text/javascript">
  
</script>
</head>


	<header></header>
	<div class="main-content">

       

        <div class="form-mini-container">


            <h1>Upload Content Form</h1>

           
		    <form class="form-mini" method="post" action="#" enctype="multipart/form-data">
                 <div class="form-row form-last-row">
                    <input type="file" name="fileToUpload" value="Upload file">
					
		
					<button type="submit">Upload</button>
               </div>

                <div class="form-row form-last-row" id="display" ">
                    <button type="submit" name="Process" id="loadgif" onClick="">Process &nbsp; <img src="ajax-loader.gif" alt="Please Wait..."/></button>
                </div>

                

                

               

                <div class="form-row form-last-row">
                    <button type="Download" name="Download">Download</button>
                </div>

            </form>
        </div>


    </div>

</body>

</html>
