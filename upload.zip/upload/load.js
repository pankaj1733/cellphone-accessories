$(form).submit(function() {
     $.ajax({
           type: "POST",
           url: "action.php", //Your URL
           data: $(form).serialize(), //post form data to your url
           success: function() {
                //your action after submit success
           }
     });

     //ajax request start. here we change the display on your class from "none" to "block"
     $(document).ajaxStart(function(){
           $(".formprocessgif").css("display","block");
     });

     //when ajax complete, we change back display to "none" to hidden loading image
     $(document).ajaxComplete(function(){
           $(".formprocessgif").css("display","none");
     });

});